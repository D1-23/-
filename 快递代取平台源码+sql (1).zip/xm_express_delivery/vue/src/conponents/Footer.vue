<template>
  <div style="background-color: #3c3c3c;height: 400px;margin-top: 40px">
    <div style="width: 50%;margin: 0 auto;display: flex;color: #c2c2c2">
      <div style="flex: 1;margin-top: 20px">
        <div style="padding: 10px 0;font-size: 18px">校园快递代取平台</div>
        <div style="padding: 5px 0">上亿人员共同打造的"快递代取网站"</div>
        <div style="padding: 5px 0">60,00000 多次代取记录</div>
        <div style="padding: 5px 0">600,000 个细分分类</div>
        <div style="padding: 5px 0">760,000,000 次接单记录</div>
        <div style="padding: 5px 0">38,000+ 代取认证</div>
      </div>
      <div style="flex: 1;margin-top: 20px">
        <div style="padding: 10px 0;font-size: 18px">关于我们</div>
        <div style="padding: 5px 0">关于校园快递代取平台联系我们</div>
        <div style="padding: 5px 0">隐私政策商标声明</div>
        <div style="padding: 5px 0">服务协议</div>
        <div style="padding: 5px 0">校园快递代取平台服务协议</div>
        <div style="padding: 5px 0">网络信息侵权通知指引</div>
        <div style="padding: 5px 0">校园快递代取平台服务监督员</div>
        <div style="padding: 5px 0">网站地图加入校园快递代取平台</div>
      </div>
      <div style="flex: 1;margin-top: 20px">
        <div style="padding: 10px 0;font-size: 18px">认证咨询服务</div>
        <div style="display: flex">
          <div style="flex: 1;padding: 10px 0">认证咨询</div>
          <div style="flex: 1;padding: 5px 0">代取员了解</div>
        </div>
        <div style="display: flex">
          <div style="flex: 1;padding: 10px 0">代取问答</div>
          <div style="flex: 1;padding: 5px 0">代取详情</div>
        </div>
        <div style="display: flex">
          <div style="flex: 1;padding: 10px 0">订单选择</div>
          <div style="flex: 1;padding: 5px 0">派送须知</div>
        </div>
        <div style="display: flex">
          <div style="flex: 1;padding: 10px 0">APP下载</div>

        </div>
        <div style="padding: 5px 0">友情链接：<a style="margin-left:10px;color: red;" href="https://space.bilibili.com/432113931">武哥聊编程</a> <a style="margin-left:10px;color: red;" href="https://space.bilibili.com/402779077">程序员青戈</a> </div>
      </div>
    </div>
    <div style="width: 100%;text-align: center;color: #c2c2c2;margin-top: 40px;font-size: 20px">
      校园代取，就上校园快递代取平台
    </div>
  </div>
</template>