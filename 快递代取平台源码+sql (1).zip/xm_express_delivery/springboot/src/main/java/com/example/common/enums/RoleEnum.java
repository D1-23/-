package com.example.common.enums;

public enum RoleEnum {
    // 管理员
    ADMIN,
    // 学生
    STUDENT,
    // 代取员
    COURIER
}
